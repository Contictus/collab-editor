# Real-Time Collaborative Markdown Editor — Spec Bundle

Bu klasör, projeye Claude Code ile başlamadan önce hazırlanmış tam spesifikasyon
paketidir. Kod içermez; kararları, mimariyi, fazları ve Claude Code çalışma
düzenini içerir.

## Ne Yapıyoruz

Birden çok kullanıcının aynı Markdown dokümanını aynı anda, veri kaybı olmadan
düzenlediği full-stack editör. CRDT (Yjs) ile çakışma çözümü, custom WebSocket
server ile senkronizasyon, op log + snapshot checkpoint ile kalıcılık.

CV satırı (hedef):
> Built a real-time collaborative Markdown editor using CRDT-based conflict
> resolution (Yjs) over a custom WebSocket server, integrated with a Next.js
> App Router frontend; persisted Yjs operation logs to PostgreSQL with periodic
> snapshot compaction for state replay and audit.

## Dosya Haritası

| Dosya | İçerik |
|-------|--------|
| `CLAUDE.md` | Claude Code kalıcı bağlamı: kararlar, INVARIANTS, komutlar, faz listesi |
| `.claude/agents/*` | Dört subagent: crdt-sync, persistence, nextjs-app, test-e2e |
| `docs/architecture.md` | Sistem görünümü, process ayrımı, veri akışı |
| `docs/data-model.md` | Prisma şeması, op log/snapshot, load/write/compaction algoritmaları |
| `docs/websocket-protocol.md` | y-protocols wire format + custom auth handshake + room yaşam döngüsü |
| `docs/concepts/crdt-vs-ot.md` | Mülakat savunması: LWW neden yanlış, OT vs CRDT |
| `docs/concepts/version-vector.md` | State vector, kısmi sıra, optimistic concurrency doğru yorumu |
| `docs/roadmap.md` | Faz 0–7, her fazın kabul kriterleri |
| `docs/claude-code-playbook.md` | Claude Code'u nasıl süreceğin — operasyonel akış |
| `docs/adr/*` | 5 mimari karar kaydı (gerekçeler ve trade-off'lar) |

## Nasıl Başlanır

1. Bu klasörü yeni bir git reposunun köküne kopyala.
2. Claude Code'u kökte aç.
3. `docs/claude-code-playbook.md`'yi takip et — Faz 0'dan başla, faz faz ilerle.

## Tech Stack

Next.js 15 (App Router, RSC, Server Actions) · React 19 · CodeMirror 6 ·
Yjs + y-protocols + y-codemirror.next · ws · PostgreSQL 16 · Prisma 6 ·
TypeScript strict · jose (JWT) · argon2id · zod · Vitest · Playwright ·
pnpm workspaces monorepo.
