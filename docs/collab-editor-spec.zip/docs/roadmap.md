# Yol Haritası — Fazlar

Her faz bağımsız test edilebilir çıktı üretir. Sıradaki faza geçmeden kabul
kriterleri yeşil olmalı. Claude Code her fazı ayrı oturumda ele almalı.

## Faz 0 — İskelet
- pnpm workspace monorepo: apps/web, apps/ws-server, packages/{db,protocol,shared}
- TypeScript strict, tsconfig base, eslint/prettier
- Prisma init + şema (data-model.md), ilk migration, docker-compose Postgres
- Health check: web `/api/health`, ws-server ping
- **Kabul:** `pnpm install`, `pnpm db:migrate`, `pnpm dev` çalışır; iki process ayağa kalkar.

## Faz 1 — Auth
- register/login Server Actions; argon2id hash; jose ile JWT; httpOnly cookie
- Oturum doğrulama helper (RSC ve ws-server ortak, packages/protocol)
- **Kabul:** kayıt/giriş çalışır; korumalı sayfa oturumsuz reddeder; vitest auth testleri.

## Faz 2 — Doküman CRUD
- Server Action: createDocument, listDocuments (owner scope)
- `/doc/[id]` Server Component: snapshot'tan SSR ilk içerik (salt-okunur bootstrap)
- **Kabul:** kullanıcı doküman oluşturur/listeler; SSR ilk metni render eder.

## Faz 3 — WS Server Sync (persistence YOK)
- ws server: upgrade auth handshake (JWT + doc yetkisi)
- Room registry, in-memory Y.Doc, y-protocols sync + awareness
- **Kabul:** iki tarayıcı sekmesi aynı odada; birinde yazılan diğerinde görünür
  (henüz reload'da kaybolur — bu normal). Playwright 2-client smoke test.

## Faz 4 — Persistence
- Y.Doc 'update' listener → DocumentUpdate append
- load-on-open: snapshot + replay
- snapshot compaction (N=100 eşik, INVARIANT sırası)
- **Kabul:** yazıp reload et → içerik kalıcı. Compaction sonrası load doğru.
  Op log satır sayısı compaction'da düşer.

## Faz 5 — Frontend Editör
- CodeMirror 6 + markdown lang + y-codemirror.next binding
- Awareness: uzak imleç, seçim, kullanıcı adı/renk
- Bağlantı durumu göstergesi (connected/syncing/offline)
- **Kabul:** iki client canlı ortak düzenleme; uzak imleçler görünür; offline
  yazıp geri gelince merge olur (veri kaybı yok).

## Faz 6 — Op Log Replay / Audit
- Endpoint: doküman için update/snapshot geçmişi; "state at update K" replay
- Basit audit görünümü (kaç edit, kim, ne zaman — persist edilen metadata'dan)
- **Kabul:** replay endpoint bilinen bir noktadaki metni doğru üretir.

## Faz 7 — Test + Sağlamlaştırma
- Playwright multi-client E2E: eşzamanlı yazma, offline/online, conflict senaryosu
- Yük notu: N client tek odada relay davranışı (manuel/betik)
- README + mimari diyagram (docs'tan) + "CRDT vs OT" özeti
- **Kabul:** E2E yeşil; README'den proje sıfırdan ayağa kalkar.

## Kapsam Dışı (bilinçli)
- Multi-node ws ölçekleme (adr/0005) — sadece dokümante et, uygulama.
- Rich text / Markdown WYSIWYG — plain+markdown yeterli.
- Yetki paylaşım UI'ı ötesi (rol/izin matrisi) — owner + basit paylaşım yeter.
