# Mimari

## Sistem Görünümü

```
┌─────────────┐     HTTPS (SSR, Server Actions, REST auth)     ┌──────────────────┐
│   Browser   │ ─────────────────────────────────────────────▶│  Next.js (web)   │
│  CodeMirror │                                                 │  App Router      │
│   + Yjs     │                                                 │  React 19 RSC    │
│  y-cm.next  │◀───── WebSocket (y-protocols sync+awareness) ──┐└────────┬─────────┘
└─────────────┘                                                │         │ Prisma
       ▲                                                        │         ▼
       │ binary Yjs updates + awareness                         │   ┌───────────┐
       ▼                                                        │   │ Postgres  │
┌──────────────────────────────────────────────────────────────┴─┐ │  - users  │
│  ws-server (bağımsız Node.js process, ws + yjs)                  │ │  - docs   │
│  - JWT handshake auth        - in-memory Y.Doc room registry     │ │  - updates│
│  - sync step1/2, update mesajları   - awareness relay            │─▶│  - snaps  │
│  - persistence: append update, load-on-open, snapshot compaction │ │           │
└──────────────────────────────────────────────────────────────────┘ └───────────┘
```

İki ayrı process, ortak Postgres şeması (`packages/db`), ortak protokol tipleri
(`packages/protocol`). Web SSR ile ilk render'ı yapar; tarayıcı bağlanınca WS
devralır ve tüm gerçek zamanlı senkronizasyon ws-server üzerinden akar.

## Neden Next içinde WebSocket değil

Next.js App Router route handler'ları request/response modelidir; uzun ömürlü
WebSocket upgrade'i native desteklemez. Seçenekler:

| Seçenek | Değerlendirme |
|--------|---------------|
| Next custom server (`server.js`) + ws | Mümkün ama App Router'ın edge/streaming avantajını bozar, tek process'e kilitler |
| Ayrı ws-server process | **Seçilen.** Ayrı ölçeklenir, ayrı deploy edilir, WS yükü SSR'ı etkilemez |
| Üçüncü parti (Pusher/Ably) | CRDT persistence kontrolünü kaybederiz, projenin amacına aykırı |

Ayrı process, "custom WebSocket server integrated into Next.js App Router" CV
iddiasını dürüst kılar: entegrasyon = ortak auth (aynı JWT), ortak DB, ortak tipler;
izolasyon = bağımsız runtime.

## Veri Akışı: Doküman Açma

1. Kullanıcı `/doc/[id]` sayfasına gider. **Server Component** JWT cookie'yi
   doğrular, Prisma ile dokümanın son snapshot'ını çeker, ilk HTML'i SSR eder
   (metin görünür — SEO/first paint için, salt-okunur bootstrap).
2. Client component mount olur, ws-server'a WebSocket açar. Cookie/JWT handshake'te
   doğrulanır.
3. Client sync step 1 (kendi state vector'ünü) gönderir. Server eksik update'leri
   step 2 ile döner. Client Y.Doc'u tam state'e ulaşır; CodeMirror içeriği güncellenir.
4. Bundan sonra her yerel düzenleme bir Yjs update üretir → WS'ten server'a → server
   otoriter Y.Doc'a uygular, persist eder, diğer client'lara relay eder.

## Version Vector / State Vector

Yjs her değişikliği `(clientID, clock)` çiftiyle etiketler. **State vector** =
her clientID için görülen en yüksek clock. İki replika state vector'lerini
değiştirerek "sende olup bende olmayan" update'leri hesaplar (`Y.encodeStateAsUpdate(doc, remoteStateVector)`).

Elle integer version tutmuyoruz çünkü tek sayaç eşzamanlı düzenlemeyi ifade edemez —
bu tam olarak last-write-wins tuzağıdır. Version vector, "hangi düzenleme hangisini
gördü" kısmi sıralamasını (partial order) taşır; last-write-wins ise total order
dayatıp kaybettirir. Ayrıntı: `docs/concepts/version-vector.md`.

## Ölçekleme Notu (uygulanmaz, farkındalık için)

Tek-node otoriter Y.Doc varsayımı, çok instance'ta bozulur (aynı doküman iki
process'te ayrışır). Prod çözümü: Redis pub/sub ile update fan-out veya sticky
routing + tek writer. Bu projede tek node; karar `docs/adr/0005.md`.
