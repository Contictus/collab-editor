# CRDT vs OT ve Last-Write-Wins Neden Yanlış

Bu dosya "zorluk noktası"nın savunmasıdır. Mülakatta bunları anlatabilmelisin.

## Last-Write-Wins Neden Kaybettirir

İki kullanıcı aynı anda düzenler. Naif model: her kayıtta tüm dokümanı gönder,
son gelen kazanır. A "Hello" → "Hello world" yaparken, B aynı anda "Hi" ekler.
İkisi de tam metni yollar; server sonuncuyu yazar. İlkinin düzenlemesi TAMAMEN
silinir. Sorun: metni tek bir opak değer olarak ele alıp değişimin YAPISINI
(hangi pozisyona ne eklendi) yok saymak. Doğru model, düzenlemeyi metin bloğu
değil, **operasyon** (insert/delete + konum + kimlik) olarak taşır.

## OT (Operational Transformation)

Her düzenleme bir operasyondur: `insert(pos, char)`, `delete(pos)`. Eşzamanlı
operasyonlar geldiğinde, birini diğerine göre **dönüştürürsün** (transform):
A pozisyon 5'e ekledi, B pozisyon 2'ye eklediyse, A'nın operasyonu B uygulandıktan
sonra pozisyon 6'ya kayar. Google Docs klasik OT kullanır.

- Artı: kompakt, düşük metadata.
- Eksi: transform fonksiyonlarını doğru yazmak çok zordur; merkezi bir sunucu
  otoritesi ve global sıralama neredeyse şart. Peer-to-peer'da patlar. Kanıtlanmış
  doğru transform matrisi yazmak notoriously zordur.

## CRDT (Conflict-free Replicated Data Type)

Her karakter global olarak benzersiz ve kalıcı bir kimlik alır (Yjs'te
`(clientID, clock)`). Konum, kırılgan integer index yerine bu kimliklere göre
(fractional/relative position) tanımlanır. İki replika aynı operasyon kümesini
herhangi bir sırayla uygulayınca AYNI sonuca yakınsar (strong eventual consistency).
Transform gerekmez; merge, veri tipinin matematiksel özelliğidir (komütatif,
asosyatif, idempotent birleştirme).

- Artı: merkezi sunucu ZORUNLU değil; sıra bağımsız; P2P çalışır; transform yok.
- Eksi: karakter başına metadata (tombstone, id) → bellek/boyut maliyeti. Yjs bunu
  agresif encoding + garbage collection ile pratik seviyeye indirir.

## Karşılaştırma

| Boyut | OT | CRDT (Yjs) |
|-------|-----|-----------|
| Merge mantığı | Transform fonksiyonları (yazması zor) | Veri tipi garantisi (hazır) |
| Merkezi sunucu | Genelde zorunlu | Zorunlu değil |
| Sıra duyarlılığı | Yüksek (global order gerekir) | Yok (komütatif) |
| Metadata maliyeti | Düşük | Yüksek ama optimize (Yjs) |
| P2P / offline | Zor | Doğal |
| Olgun kütüphane | ShareDB | Yjs, Automerge |

## Bu Projede Neden CRDT (Yjs)

1. Transform doğruluğu riskini elemek — kendi OT'unu yazmak proje kapsamını aşar
   ve hataya açıktır.
2. Offline düzenleme + sonradan merge doğal gelir.
3. Version vector (state vector) kavramını Yjs zaten sağlar; version integer
   tutmanın total-order tuzağından kaçınırız.
4. Persistence binary update olarak temiz — op log'a doğrudan yazılır.

## Version Vector'ün Rolü (özet)

Tek integer version = total order = "kim sonuncu" = last-write-wins tuzağı.
Version/state vector = clientID başına clock = kısmi sıra = "kim kimi gördü".
Bu, eşzamanlılığı (concurrency) tespit edip iki düzenlemeyi de koruyarak merge
etmeyi mümkün kılar. Detay: `version-vector.md`.
