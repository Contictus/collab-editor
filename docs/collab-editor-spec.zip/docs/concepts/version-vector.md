# Version Vector / State Vector

## Problem

Tek sayaçlı versiyon (`version: 7`) toplam sıralama (total order) dayatır.
"Hangi versiyon en son?" sorusuna cevap verir ama "bu iki düzenleme birbirini
gördü mü, yoksa eşzamanlı mı?" sorusuna veremez. Eşzamanlılığı göremeyince tek
çözüm birini atmaktır → last-write-wins.

## Version Vector Nedir

Her replikanın (client) kendi monoton sayacı vardır. Version vector, tüm
replikaların o an bilinen en yüksek sayaçlarının haritasıdır:

```
{ clientA: 12, clientB: 7, clientC: 3 }
```

Anlamı: "clientA'nın 12. operasyonuna, clientB'nin 7., clientC'nin 3.'sine kadar
her şeyi gördüm." İki vektörü karşılaştırınca üç durum çıkar:

- V1 ≥ V2 her bileşende → V1, V2'yi görmüş (causal olarak sonra).
- V2 ≥ V1 → tersi.
- Ne biri ne öbürü (bazı bileşende V1>, bazısında V2>) → **eşzamanlı (concurrent)**.
  İşte last-write-wins'in kaybettirdiği tam bu durumdur; CRDT ise ikisini merge eder.

## Yjs'te Karşılığı: State Vector

Yjs her struct'ı `(clientID, clock)` ile işaretler. `Y.encodeStateVector(doc)`
o dokümanın state vector'ünü (clientID → en yüksek clock) binary olarak verir.

Senkronizasyonun temeli:

```
Client → Server: syncStep1 = encodeStateVector(clientDoc)
Server: diff = encodeStateAsUpdate(serverDoc, clientStateVector)
        // "senin state vector'üne göre sende olmayan her şey"
Server → Client: syncStep2 = diff
Client: applyUpdate(clientDoc, diff)
```

Bu yüzden CLAUDE.md INVARIANT #5: elle version integer tutma. Yjs'in state
vector'ü zaten kısmi sıralamayı ve eksik-diff hesabını doğru yapıyor. Kendi
integer'ını eklersen ya gereksiz ya da yanlış (total order) olur.

## Optimistic Concurrency Bağlantısı

Projenin adı "optimistic concurrency" içeriyor. Klasik optimistic locking
(version integer + "if version matches then update else reject") ilişkisel
kayıtlar için uygundur ama metin birlikte-düzenlemede reddetmek = kullanıcı
düzenlemesini atmak demektir. Burada "optimistic" olan kısım: client yerel
düzenlemeyi anında uygular (sunucu onayını beklemez), çakışma sonradan CRDT ile
otomatik çözülür. Reddetme yok, merge var. Bu, doğru yorumlanmış optimistic
concurrency'dir — reject değil, reconcile.
