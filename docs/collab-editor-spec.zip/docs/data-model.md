# Veri Modeli ve Persistence

## Prisma Şeması (hedef)

```prisma
model User {
  id        String   @id @default(cuid())
  email     String   @unique
  password  String   // argon2id hash
  createdAt DateTime @default(now())
  documents Document[]
}

model Document {
  id        String   @id @default(cuid())
  title     String
  ownerId   String
  owner     User     @relation(fields: [ownerId], references: [id])
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
  updates   DocumentUpdate[]
  snapshots DocumentSnapshot[]
}

// Op log — append-only. Her satır bir Yjs binary update.
model DocumentUpdate {
  id         BigInt   @id @default(autoincrement())
  documentId String
  document   Document @relation(fields: [documentId], references: [id])
  update     Bytes    // Yjs update (Uint8Array)
  clock      Int      // monoton sıra (opsiyonel audit için)
  createdAt  DateTime @default(now())

  @@index([documentId, id])
}

// Checkpoint — belirli aralıklarla full state snapshot.
model DocumentSnapshot {
  id            BigInt   @id @default(autoincrement())
  documentId    String
  document      Document @relation(fields: [documentId], references: [id])
  state         Bytes    // Y.encodeStateAsUpdate(doc)
  upToUpdateId  BigInt   // bu snapshot bu update id'sine kadar olanları kapsar
  createdAt     DateTime @default(now())

  @@index([documentId, id])
}
```

## Yükleme Algoritması (load-on-open)

Bir doküman odası ilk açıldığında server tarafında Y.Doc kurulumu:

```
1. En son snapshot'ı çek (upToUpdateId = S).
2. Snapshot varsa: Y.applyUpdate(doc, snapshot.state).
3. id > S olan tüm DocumentUpdate'leri sırayla Y.applyUpdate ile uygula (replay).
4. Snapshot yoksa: tüm update'leri baştan replay et.
```

Bu, event-sourcing-lite'ın "replay" kısmıdır: full state saklamak yerine
op log'u yeniden oynatarak state'i yeniden inşa edersin. Snapshot, replay
maliyetini sınırlayan checkpoint'tir.

## Yazma Algoritması (persist on update)

Bir client update gönderdiğinde:

```
1. Otoriter Y.Doc'a Y.applyUpdate ile uygula.
2. DocumentUpdate satırı olarak append et (aynı binary).
3. Diğer client'lara relay et.
4. Bu doküman için update sayacı N'e ulaştıysa compaction tetikle.
```

## Snapshot / Compaction

```
1. snapshotState = Y.encodeStateAsUpdate(authoritativeDoc)
2. lastId = o an bilinen en yüksek DocumentUpdate.id
3. TX: DocumentSnapshot(state=snapshotState, upToUpdateId=lastId) insert
4. TX (aynı veya sonraki): id <= lastId olan DocumentUpdate'leri sil (prune)
```

INVARIANT: snapshot commit'i prune'dan ÖNCE persist edilmeli. Sıra bozulursa
crash anında veri kaybı olur. Prisma transaction ile atomik yap ya da
"snapshot committed" doğrulandıktan sonra prune et.

Compaction eşiği (N) yapılandırılabilir; başlangıç için N=100. Ayrıca
awareness/presence verisi ASLA persist edilmez (efemerdir).

## Audit / Replay Görünümü (Faz 6)

Op log korunduğu sürece (ya da snapshot + sonrası), bir dokümanın herhangi bir
noktadaki halini yeniden üretebilirsin. Basit audit endpoint'i: bir doküman için
update sayısını, snapshot geçmişini, ve "state at update K" replay'ini döner.
Bu, CV'deki "state replay and audit" iddiasının somut kanıtıdır.

> Not: Tam zaman-yolculuğu (arbitrary point-in-time) için prune edilen update'ler
> kaybolur. Tam audit istiyorsan compaction'da update'leri silmek yerine
> "archived" işaretle. Trade-off `docs/adr/0004.md`.
