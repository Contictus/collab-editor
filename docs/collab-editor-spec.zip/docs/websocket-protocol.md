# WebSocket Protokolü

`y-websocket`'in hazır server'ını KULLANMIYORUZ. `y-protocols`'un wire format'ını
(sync + awareness) yeniden kullanıp, auth ve persistence'ı kendimiz bağlıyoruz.

## Mesaj Çerçevesi

Her mesaj `lib0/encoding` ile encode edilen binary'dir. İlk varInt = mesaj tipi:

| Tip | Değer | Anlam |
|-----|-------|-------|
| `messageSync` | 0 | y-protocols/sync alt protokolü (step1/step2/update) |
| `messageAwareness` | 1 | y-protocols/awareness (cursor, presence, isim/renk) |
| `messageAuth` | 2 | (opsiyonel) auth durumu / red mesajı |

Sync alt tipleri (y-protocols/sync içinde):
- `syncStep1`: gönderenin state vector'ü — "bende bunlar var"
- `syncStep2`: eksik update'ler — "sende olmayanlar bunlar"
- `syncUpdate`: yeni yerel update yayını

## Bağlantı Handshake (auth — bizim eklediğimiz katman)

`y-websocket`'te olmayan, INVARIANT #2'yi karşılayan kısım:

```
1. Client WS açar: wss://ws-host/?doc=<docId>
   JWT httpOnly cookie upgrade request header'ında gider (aynı domain) VEYA
   query param / ilk messageAuth ile token gönderilir.
2. Server `upgrade` event'inde:
   - JWT'yi jose ile doğrula (imza, exp).
   - Kullanıcının docId üzerinde yetkisi var mı? (Prisma: owner veya paylaşım).
   - Başarısız → socket'i 4401 close code ile kapat, ODAYA EKLEME.
3. Başarılı → socket odaya (room) eklenir, sync başlar.
```

Auth handshake bitmeden hiçbir sync/awareness mesajı işlenmez.

## Oda (Room) Yaşam Döngüsü

```
- Room = { docId, Y.Doc (otoriter), Set<WebSocket>, awareness }
- İlk client bağlanınca: load-on-open (snapshot + replay) → Y.Doc kurulur.
- Y.Doc'a 'update' listener: (update) => { persist(update); broadcast(update, hariç kaynak) }
- Client mesajı:
    messageSync → readSyncMessage; syncStep1 gelirse syncStep2 ile cevapla;
                  syncUpdate gelirse Y.applyUpdate (bu 'update' listener'ı tetikler)
    messageAwareness → awareness state uygula, diğerlerine relay et (persist ETME)
- Son client ayrılınca: son bir snapshot al, Y.Doc'u memory'den düşür (LRU/timeout).
```

## Sıra Garantileri

- WS aynı bağlantıda mesaj sırasını korur (TCP). Yjs update'leri idempotent ve
  komütatiftir; sıra bozulsa bile CRDT merge doğru sonuç verir — ama persist
  sırasında `id` autoincrement ile monoton log tutulur (replay determinizmi).
- Aynı update iki kez uygulanırsa Yjs yok sayar (idempotent). Bu, at-least-once
  relay'i güvenli kılar.

## Neden bu tasarım "olgun"

- Wire format'ı yeniden icat etmedik (y-protocols) → interop, az bug.
- Auth + yetkilendirme + persistence bizde → gerçek kontrol, gerçek CV iddiası.
- Awareness efemer, sync kalıcı ayrımı net → doğru veri sınıflandırması.
