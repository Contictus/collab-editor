# ADR 0001 — CRDT (Yjs) over OT

## Bağlam
E�zamanlı metin düzenlemede çakışma çözümü gerekiyor. Seçenekler: OT, CRDT.

## Karar
CRDT, Yjs kütüphanesi ile. `Y.Text`.

## Gerekçe
- Kendi OT transform fonksiyonlarını doğru yazmak yüksek riskli ve kapsam dışı.
- CRDT sıra bağımsız, offline dostu, merkezi sunucu zorunlu değil.
- Yjs olgun, agresif encoding + GC ile metadata maliyetini pratik seviyeye indirir.

## Sonuçlar
- Karakter başına metadata var (kabul edildi, Yjs optimize ediyor).
- Persistence binary update olarak temiz akıyor.
- Detay: docs/concepts/crdt-vs-ot.md
