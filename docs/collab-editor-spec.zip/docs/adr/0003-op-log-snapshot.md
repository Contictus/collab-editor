# ADR 0003 — Op Log + Snapshot Checkpoint Persistence

## Bağlam
Yjs state'i kalıcı olmalı. Seçenekler: sadece snapshot (full state), sadece op log,
hibrit.

## Karar
Hibrit: append-only op log + periyodik snapshot compaction.

## Gerekçe
- Sadece snapshot: her yazımda full state = pahalı, audit/replay yok.
- Sadece op log: sınırsız büyür, load'da tüm geçmiş replay = yavaş.
- Hibrit: snapshot replay maliyetini sınırlar, op log replay + audit sağlar.

## Sonuçlar
- Compaction eşiği N (başlangıç 100), yapılandırılabilir.
- INVARIANT: snapshot commit → sonra prune.
- Tam point-in-time audit için prune yerine archive seçeneği (adr/0004).
