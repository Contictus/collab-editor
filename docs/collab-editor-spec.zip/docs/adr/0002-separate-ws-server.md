# ADR 0002 — Ayrı WebSocket Server Process

## Bağlam
Next.js App Router native WebSocket upgrade desteklemez.

## Karar
Bağımsız Node.js ws-server process. Next custom server DEĞİL, üçüncü parti DEĞİL.

## Gerekçe
- Custom server App Router streaming/edge avantajını bozar, tek process'e kilitler.
- Ayrı process bağımsız ölçeklenir/deploy edilir; WS yükü SSR'ı etkilemez.
- Üçüncü parti CRDT persistence kontrolünü kaybettirir, proje amacına aykırı.

## Entegrasyon Yüzeyi
Ortak JWT (aynı auth), ortak Postgres (packages/db), ortak tipler (packages/protocol).

## Sonuçlar
- İki process orchestration (concurrently/turbo, docker-compose).
- CV iddiası dürüst: entegre ama izole.
