# ADR 0004 — Compaction'da Prune vs Archive

## Bağlam
Snapshot sonrası eski update'ler silinebilir (prune) veya saklanabilir (archive).

## Karar
Başlangıç: prune (basitlik + boyut). Audit ihtiyacı artarsa archive flag'i.

## Trade-off
- Prune: küçük DB, ama snapshot öncesi keyfi point-in-time kaybolur.
- Archive: tam zaman-yolculuğu, ama sınırsız büyüme + GDPR/saklama sorumluluğu.

## Sonuç
MVP prune. "state at update K" replay'i yalnızca mevcut (post-snapshot) log +
snapshot ile sınırlı. README'de bu sınır açıkça belirtilir.
