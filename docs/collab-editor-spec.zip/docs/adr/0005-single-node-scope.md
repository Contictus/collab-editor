# ADR 0005 — Tek Node Kapsamı (Ölçekleme Ertelendi)

## Bağlam
Otoriter Y.Doc tek process'te tek instance varsayımı çok-instance'ta bozulur.

## Karar
Bu proje tek node. Multi-node ölçekleme UYGULANMAZ, sadece dokümante edilir.

## Prod Çözümü (uygulanmayan, farkındalık)
- Redis pub/sub ile update fan-out (her instance diğerlerinin update'ini alır), veya
- Sticky routing + doküman başına tek writer (consistent hashing).
- Awareness için ayrıca presence fan-out.

## Sonuç
Mülakatta "nasıl ölçeklerdin" sorusuna net cevap; kod tek node kalır.
